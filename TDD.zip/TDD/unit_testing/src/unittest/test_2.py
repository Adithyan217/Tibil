from src.main.add import *

def test_one():
    assert add(2,2)==4
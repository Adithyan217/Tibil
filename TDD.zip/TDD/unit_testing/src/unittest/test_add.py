from src.main.add import *


def test_add_positive():
    assert add(2, 2) == 4


def test_add_negative():
    assert add(-2, -5) == -7


def test_add_neg_pos():
    assert add(3, -1) == 2


def test_add_positive_output_not_zero():
    assert add(1, 1) != 0


def test_add_positive_output_not_negative():
    assert add(2, 2) > 0


def test_add_negative_output_less_than_zero():
    assert add(-2, -2) < 0


def test_add_strings():
    assert add("hello", "world") == "helloworld"


def test_add_string_output_not_int():
    assert type(add("1", "2")) != int


def test_add_float():
    assert add(0.5, 0.3) == 0.8


def test_add_float_and_integer():
    assert add(1, 0.5) == 1.5


def test_add_fractions():
    assert add(1 / 2, 1 / 2) == 1


def test_add_string_and_int_():
    assert add("hello", 77) == "invalid input"


def test_add_dict():
    assert add({1: "a"}, {3: "b"}) == "invalid input"


def test_add_set():
    assert add({1, 2}, {3, 4}) == "invalid input"


def test_add_list_tuple():
    assert add([1, 2], (3, 4)) == "invalid input"


def test_add_bool_list():
    assert add(True, [1, 2]) == "invalid input"


def test_add_int_list():
    assert add(1, [1, 2]) == "invalid input"


def test_add_str_list():
    assert add("a", [1, 2]) == "invalid input"


def test_add_dict_set():
    assert add({1, "a"}, {2, "b"}) == "invalid input"


def test_add_list_set():
    assert add([1, 2], {1, 2}) == "invalid input"

def add(a, b):
    try:
        result = a + b
        return result
    except TypeError:
        return "invalid input"

print(add(1,"wee"))
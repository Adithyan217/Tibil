# pycalc
A python calculator project 

## How to Use
Execute `calc.py`: 

    $ python calc.py

## Supported Operations
| operator |    function    |
|----------|----------------|
| +        | addition       |
| -        | subtraction    |
| *        | multiplication |
| /        | division       |

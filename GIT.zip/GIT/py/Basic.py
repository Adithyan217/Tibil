#Python program to find the minimum among five numbers.
'''a=int(input("enter a number"))
b=int(input("enter b number"))
c=int(input("enter c number"))
d=int(input("enter d number"))
e=int(input("enter e number"))
if a<b and a<c and a<d and a<e:
    print(a)
elif b<c and b<d and b<e:
    print(b)
elif c<d and c<e:
    print(c)
elif d<e:
    print(d)
else:
    print(e)'''

print("h")

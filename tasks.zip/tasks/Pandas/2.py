# Replace all column values which contain ‘?’ and n.a with NaN.

import pandas as pd
df=pd.read_csv('auto.csv')
df.replace('l','NaN',inplace=True)
print(df.to_string())

# Find the average mileage of each car making company

import pandas as pd

df=pd.read_csv('auto.csv')

d=df.groupby('company')['average-mileage'].mean()
print(d)
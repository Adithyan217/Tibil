# Concatenate two data frames using the following conditions
import pandas as pd

Car_Price = {'Company': ['Toyota', 'Honda', 'BMV', 'Audi'], 'Price': [23845, 17995, 135925 , 71400]}

car_Horsepower = {'Company': ['Toyota', 'Honda', 'BMV', 'Audi'], 'horsepower': [141, 80, 182 , 160]}

df1=pd.DataFrame(Car_Price)
df2=pd.DataFrame(car_Horsepower)

# d=pd.concat([df1,df2],ignore_index=True)
d=df1.groupby
df1.loc[1,'Company']="boom"
print(df1)

# total cars per company
import pandas as pd

df=pd.read_csv('auto.csv')

d=df.groupby('company').count()
print(d.iloc[:,1])
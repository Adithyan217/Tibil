# #                                                     PANDAS
# #
#
#
# import csv
#
import pandas as pd
#
# # try:
# #   mydataset = {
# #     'cars': ["BMW", "Volvo", "Ford", "BENZ"],
# #     'passings': [3, 7, 2],
# #     'available': [2, 5, 3,9]
# #   }
# #   myvar = pd.DataFrame(mydataset)
# #   print(myvar)
# #   print(pd.__version__)
# # except:
# #   print('array of diff len')
#
#
# # a = ['a','b','c']
# #
# # myvar = pd.Series(a)
# # myvar2 = pd.Series(a, index = ["x", "y", "z"])
# #
# #
# # print(myvar)
# # print(myvar2)
# # print(myvar[0])
# # print(myvar2["x"])
#
# #
# # calories = {"day1": 420, "day2": 380, "day3": 390}
# #
# # myvar = pd.Series(calories)
# # myvar2 = pd.Series(calories, index = ["day1"])
# #
# #
# # print(myvar)
# # print(myvar2)
#
#
#
# # data = {
# #   "calories": [420, 380, 390],
# #   "duration": [50, 40, 45]
# # }
#
# # #load data into a DataFrame object:
# # df = pd.DataFrame(data)
#
# # print(df.loc[2])
#
#
#
# # data=[
# #     ['Name', 'Age', 'City'],
# #     ['John', 30, 'New York'],
# #     ['Alice', 25, 'Los Angeles'],
# #     ['Bob', 35, 'Chicago']
# # ]
# # with open('d.csv','w') as file:
# #     c=csv.writer(file)
# #     c.writerows(data)
#
#
#
# #                         CSV                         #
# # df = pd.read_csv('data.csv')
# # # pd.options.display.max_rows=9999
# # print(df)
# # print(df.head(10))
# # print(df.tail(10))
# # print(pd.options.display.max_rows)
# # print(pd.options.display.min_rows)
#
#
#
# #                          JSON                          #
#
# # df = pd.read_json('data.json')
# #
# # # print(df.to_string())
# # print(df.info())
#
#
#
# #                           CLEANING EMPTY CELLS IN ROW
#
#
# # df=pd.read_csv('data1.csv')
# # # df2=df.dropna()                             # removes rows containing null values from new dataframe
# # print(df2.to_string())
# #
# # # print(df.to_string())
# #
# # # df.dropna(inplace = True)                   # removes the rows with null value from the orginal data frame
# #
# # df.fillna(130, inplace = True)              # fills the empty cells with the given valuess
# #
# # # df['calories'].fillna(200,inplace=True)       # fills the empty cells of the specified columns
# #
# # print(df.to_string())
#
#
#
#
# # df=pd.read_csv('data1.csv')
# #
# # x=df['Calories'].mode()[0]
# # # x=df['Calories'].mean()
# # # x=df['Calories'].median()
# #
# # df.fillna(x,inplace=True)
# #
# # print(df.to_string())
#
#
#
#
# #                             CLEANING WRONG FORMAT
#
# #
# # df = pd.read_csv('data2.csv')
# #
# # df['Date'] = pd.to_datetime(df['Date'])
# #
# # print(df.to_string())
#
#
#
# #                             CLEANING WRONG DATA
#
#
# # df = pd.read_csv('data2.csv')
#
#
# # df.loc[7,'Duration']=45                          # it will change the values at that position
# # print(df.to_string())
#
# # print(df.index)
#
# # for x in df.index:
# #     if df.loc[x,'Duration']>50:
# #         df.loc[x,'Duration']=50
# #
# # print(df.to_string())
#
#
# # for x in df.index:
# #     if df.loc[x,'Duration']>100:
# #         df.drop(x,inplace=True)
# # print(df.to_string())
#
#
#
#
#
# # df = pd.read_csv('data.csv')            #removes row in even index
# #
# # for x in df.index:
# #   if x%2==0:
# #     df.drop(x, inplace = True)
# #
# # print(df.to_string())
#
#
#
# #                             CORRELATION
#
# # df = pd.read_csv('data.csv')
# # print(df.corr())
#
#
#
# #                            PLOTING
# # import sys
# # import matplotlib
# # matplotlib.use('Agg')
# #
# import pandas as pd
# import matplotlib.pyplot as plt
#
# df = pd.read_csv('data.csv')
#
# df.plot()
#
# plt.show()
# #
# # #Two  lines to make our compiler able to draw:
# # plt.savefig(sys.stdout.buffer)
# # sys.stdout.flush()
#
#
#
#
# # #                   exporting to csv
#
# # import pandas as pd
# # data={
# #     'Name':['Ram','Sam','Jam'],
# #     'Marks':[22,31,27],
# #     'Age':[18,19,17]
# # }
# # df=pd.DataFrame(data)
# # df.index=['one','two','three']
# # # df.to_csv('csvdata.csv')
# # print(df)
#
#
#
#
# #                             describe
#
# # import pandas as pd
# #
# # df=pd.read_csv('data1.csv')
# # print(df.describe())
#
#
#
# #                            groupby()
#
# import pandas as pd
#
# # Sample DataFrame
# data = {
#     'Gender': ['Male', 'Female', 'Male', 'Female', 'Male'],
#     'Age': [25, 30, 35, 40, 45],
#     'Salary': [50000, 60000, 70000, 80000, 90000]
# }
# df = pd.DataFrame(data)
#
# # Grouping by the 'Gender' column and calculating the mean salary
# # grouped = df.groupby('Gender').agg({'Age':['min','max','count','mean']})
# g=df.groupby(['Gender','Salary'])
# # print(grouped)
# print(g.groups)
# print(gg)
#
#
#
# # import pandas as pd
# #
# # # Sample DataFrames
# # df1 = pd.DataFrame({'A': [1, 2, 3], 'B': [4, 5, 6]})
# # df2 = pd.DataFrame({'A': [7, 8, 9], 'B': [10, 11, 12]})
# #
# # # Concatenate along rows
# # combined_df = pd.concat([df1, df2],axis=1)
# # print(combined_df)
#
#
#
# # df1 = pd.DataFrame({'ID': [1, 2, 3], 'Name': ['Alice', 'Bob', 'Charlie']})
# # df2 = pd.DataFrame({'ID': [1, 2, 4], 'Age': [25, 30, 35]})
# #
# # # Merge DataFrames based on 'ID'
# # merged_df = pd.merge(df1, df2, on='ID', how='inner')
# # print(merged_df)
#
#
# # Sample DataFrames
# # df1 = pd.DataFrame({'A': [1, 2, 3]})
# # df2 = pd.DataFrame({'B': [4, 5, 6]})
# #
# # # Join DataFrames based on index
# # joined_df = df1.join(df2)
# # print(joined_df)
#
#
#
# Sample DataFrames
# df1 = pd.DataFrame({'A': [1, 2, 3]})
# df2 = pd.DataFrame({'A': [4, 5, 6]})
#
# # Append rows from df2 to df1
# appended_df = df1._append(df2, ignore_index=True)
# print(appended_df)
#
#
#
# ######            PLOTING
# #
# import pandas as pd
# import matplotlib.pyplot as plt
#
# # Sample DataFrame
# data = {
#     'Year': [2010, 2011, 2012, 2013, 2014],
#     'Sales': [10000, 15000, 20000, 25000, 30000]
# }
# df = pd.DataFrame(data)
#
# # Plotting the data
# df.plot(x='Year', y='Sales', kind='line', marker='o', linestyle='--')
# plt.title('Sales Over Years')
# plt.xlabel('Year')
# plt.ylabel('Sales')
# plt.grid(True)
# plt.show()
#
#
#
# # import pandas as pd
# #
# # Sample DataFrame
# data = {
#     'Date': ['2024-01-01', '2024-01-01', '2024-01-02', '2024-01-02'],
#     'Category': ['A', 'B', 'A', 'B'],
#     'Sales': [100, 150, 200, 250]
# }
# df = pd.DataFrame(data)
#
# # Creating a pivot table
# pivot_table = df.pivot_table(index='Date', columns='Category', values='Sales', aggfunc='sum')
# print(pivot_table)
# print(df)
#
#
# # def fun(a):
# #     return a
# # a=fun(int(input("enter")))
# # var=lambda a:a*3
# # print(var(a))
#
#
# # from array import array
# #
# # data=array('i',[1,3])
# # print(type(data))
#
# import pandas as pd

# # Sample time series data
# date_range = pd.date_range(start='2024-01-01', end='2024-12-31', freq='D')
# # print(date_range)
# data = {'Date': date_range, 'Value': range(len(date_range))}
# # print(data)
# df = pd.DataFrame(data)
#
# # Set 'Date' column as the index
# df.set_index('Date', inplace=True)
#
#
# # Resample to monthly frequency and calculate the sum of values
# df_resampled = df.resample('w').sum()
#
# print("Original DataFrame:")
# print(df)
# print("\nResampled DataFrame (monthly sum):")
# print(df_resampled)

# # print(pd.options.display.max_rows)
# df=pd.read_csv(r'D:\adi\Tibil\tasks\Pandas\auto.csv')
# g=df.groupby('body-style')['company'].count()
# # max=df[df['price']>10000]
# # print(df)
# max=df['company'].loc[df['price']>20000]
# m=df['price'].apply(lambda x:x*2)
# print(df)
# print(m)

#
# data={"a":["a","b","c","d","e"]}
# df=pd.DataFrame(data)
# print(df)
# df2=df.reindex([3,1,4,2,0])
# print(df2)2


# date=pd.date_range(start='2024-1-1',end='2024-12-31',freq='ME')
# v=pd.bdate_range(start='2024-1-1',end='2024-12-31',freq='ME')
# print(pd.DataFrame(v))


# import pandas as pd

# # Sample DataFrame
# data = {
#     'A': [1, 2, 3, 4, 5],
#     'B': [5, 4, 3, 2, 1],
#     'C': [2, 3, 4, 3, 2]
# }
#
# df = pd.DataFrame(data)
# v=df.transpose()
# f=df.loc[df['B']>4]
#
# # Bar plot
# # df.plot.bar(title='Bar Plot', xlabel='X-axis', ylabel='Y-axis')
# print(f)

# print()

#
# import pandas as pd
#
# # Creating the first DataFrame
# dict1 = {
#     'ID': [1, 2, 3, 4,5],
#     'Name': ['Alice', 'Bob', 'Charlie', 'David','h'],
#     'Age': [25, 30, 35, 40,88]
# }
# # df1 = pd.DataFrame(data1)
# #
# # # Creating the second DataFrame
# dict2 = {
#     'ID': [1, 2, 3, 4],
#     'Salary': [50000, 60000, 70000, 80000],
#     'Department': ['HR', 'Engineering', 'Finance', 'Marketing']
# }
# df2 = pd.DataFrame(data2)
#
# # Performing a left join using df.join
# # joined_df = df1.join(df2.set_index('ID'), on='ID')
# # joined_df = df1.merge(df2, on='ID',how='right')
# concat=pd.concat([df1,df2],axis=1,join='')
# # Printing the joined DataFrame
# # print(joined_df)
# print(concat)


dict1 = {
    'ID': [1, 2, 3, 4,5],
    'Name': ['Alice', 'Bob', 'Charlie', 'David','h'],
    'Age': [25, 30, 35, 40,88]
}
dict2 = {
    'ID': [1, 2, 3, 4],
    'Salary': [50000, 60000, 70000, 80000],
    'Department': ['HR', 'Engineering', 'Finance', 'Marketing']
}

print(dict1==dict2)

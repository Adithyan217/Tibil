# find each companies highest price

import pandas as pd

df=pd.read_csv('auto.csv')

d=df.groupby('company')['price'].max()
print(d)
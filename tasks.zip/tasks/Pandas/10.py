# Merge two df
import pandas as pd

Car_Price = {'Company': ['Toyota', 'Honda', 'BMV', 'Audi'], 'Price': [23845, 17995, 135925 , 71400]}

car_Horsepower = {'Company': ['Toyota', 'Honda', 'BMV', 'Audi'], 'horsepower': [141, 80, 182 , 160]}

df1=pd.DataFrame(Car_Price)
df2=pd.DataFrame(car_Horsepower)
d=pd.merge(df1,df2,how='inner',on='Company')
v=df1.groupby()
print(v)
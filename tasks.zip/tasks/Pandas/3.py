#  Find the most expensive car company name
# Print the most expensive car’s company name and price.

import pandas as pd

df=pd.read_csv('auto.csv')
max=df['price'].idxmax()
v=df.loc[max,['company','price']]
print(v)

# Print All Toyota Cars details
import pandas as pd

df=pd.read_csv('auto.csv')
print(df[df['company']=='toyota'])


# for x in df.index:
#     if df.loc[x,'company']!='toyota':
#         # d=df.loc[x,'company']
#         df.drop(x,axis=0,inplace=True)
# print(df.to_string())







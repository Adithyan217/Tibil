# Sort all cars by Price column

import pandas as pd

df=pd.read_csv('auto.csv')
df.dropna(inplace=True)
df.sort_values('price',ignore_index=True,inplace=True,ascending=False)
print(df.to_string())
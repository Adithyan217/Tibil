import pandas as pd

df=pd.read_csv('auto.csv')

print('FIRST FIVE ROWS')
print(df.head())
print('LAST FIVE ROWS')

print(df.tail())


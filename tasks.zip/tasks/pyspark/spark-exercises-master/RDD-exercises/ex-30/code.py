# Python program to extract Pyspark random sample through
# sample function with fraction and withReplacement as arguments

# Import the SparkSession library
from pyspark.sql import SparkSession

# Create a spark session using getOrCreate() function
spark_session = SparkSession.builder.getOrCreate()

# Read the CSV file
data_frame = csv_file = spark_session.read.csv('/content/student_data.csv',
                                               sep=',', inferSchema=True, header=True)

# Extract random sample through sample function using
# withReplacement (value=True) and fraction as arguments
data_frame.sample(True, 0.8).collect()

# Again extract random sample through sample function using
# withReplacement (value=False) and fraction as arguments
data_frame.sample(False, 0.8).collect()
from pyspark.sql import SparkSession

# Create SparkSession
spark = SparkSession.builder \
    .appName("DataFrame Creation Example") \
    .getOrCreate()

# Data
data = [('Alice', 34), ('Bob', 45), ('Charlie', 28)]

# Create DataFrame
df = spark.createDataFrame(data, ['Name', 'Age'])

print(df)
df.printSchema()

# df.show()

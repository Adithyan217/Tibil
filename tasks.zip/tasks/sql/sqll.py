import psycopg2

# Connect to the database
conn = psycopg2.connect(
    host='localhost',
    database='tibil',
    user='postgres',
    password='root'
)

# Create a cursor object
cursor = conn.cursor()

# Execute SQL commands
# cursor.execute("CREATE TABLE IF NOT EXISTS users (id SERIAL PRIMARY KEY, name VARCHAR(255), age INT)")
cursor.execute("INSERT INTO users (name, age) VALUES ('johniss', 22)" )
# cursor.execute('drop table users')
# # Commit the changes
conn.commit()
#
cursor.execute('select * from users')
rows = cursor.fetchall()
for row in rows:
        print(row)

# import mysql.connector
#
# con=mysql.connector.connect(
#     host='localhost',
#     user='root',
#     password='root',
#     database='dabba'
# )
#
# cursor=con.cursor()
#
# cursor.execute('select * from app_boom')





# import sqlite3
#
# # Connect to the database (creates the database if it doesn't exist)
# conn = sqlite3.connect('dabba.db')
#
# # Create a cursor object
# cursor = conn.cursor()
#
# # cursor.execute('''CREATE TABLE IF NOT EXISTS arrr
# #                   (id INTEGER PRIMARY KEY, name TEXT, age INTEGER)''')
# # cursor.execute("INSERT INTO arrr (name, age) VALUES (?, ?)", ('Alice', 30))
#
# cursor.execute('select * from app_boom')
#
# # Commit the changes
# conn.commit()




import psycopg2

# Connect to the database
conn = psycopg2.connect(
    host='localhost',
    database='tibil',
    user='postgres',
    password='root'
)

# Create a cursor object
cursor = conn.cursor()

# Execute SQL commands
# cursor.execute("CREATE TABLE IF NOT EXISTS users (id SERIAL PRIMARY KEY, name VARCHAR(255), age INT)")
cursor.execute("INSERT INTO users (name, age) VALUES ('john', 22)" )
# cursor.execute('drop table users')
# # Commit the changes
conn.commit()
#
cursor.execute('select * from users')
rows = cursor.fetchall()
for row in rows:
        print(row)



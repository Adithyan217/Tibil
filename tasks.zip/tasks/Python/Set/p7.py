# Python program to check if two sets are disjoint.
a={3,1,2,22}
b={4,5,6,7,8,9,0}
# dis=True
# for i in a:
#     if i in b:
#         dis=False
# if dis==True:
#     print('a and b are disjoint')
# else:
#     print('not')


for i in a:
    if i in b:
        print('not disjoint')
        break
else:
        print('Disjoint')
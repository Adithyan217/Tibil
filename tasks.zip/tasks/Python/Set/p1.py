# Python program to find the intersection of two sets.
a={1,2,3,4,5}
b={3,4,5,6,7,8,9,0}

for i in a:
    if i in b:
        print(i,end=' ')

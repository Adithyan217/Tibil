# Python program to check if a set is a proper subset of another set.

pset={3,4,5,6,7,8}
sset={3,4,5,6,7}


if sset!=pset:
    d = set()
    for i in sset:
        if i in pset:
            d.add(i)

    if sset == d:
        print('proper subset')
    else:
        print('not')
else:
    print('not')




d = set()
for i in sset:
    if i in pset:
        d.add(i)

if sset == d:
    c=True
else:
    c=False

if c == True:
    if sset == pset:
        print('subset but not a proper subset')
    else:
        print('proper subset')



# Python program to perform set operations (union, intersection, difference) using set methods.

a={3,1,2,22}
b={3,4,5,6,7,8,9,0}

print(a.union(b))
print(a.intersection(b))
print(a.difference(b))
print(b.difference(a))
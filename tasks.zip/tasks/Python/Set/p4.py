# Python program to check if a set is a subset of another set.
pset={3,4,5,6,7,8,9,0}
sset={3,4,5,6,7}



d=set()
for i in sset:
    if i in pset:
        d.add(i)

if sset==d:
    print('subset')
else:
    print('not')





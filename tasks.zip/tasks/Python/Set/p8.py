# Python program to find the Cartesian product of two sets.
a={3,1}
b={3,4}
print({(x,y) for x in a for y in b})

c=set()
for i in a:
    for j in b:
        c.add((i,j))
print(c)
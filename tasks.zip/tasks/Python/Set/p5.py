# Python program to remove duplicates from a list and convert it to a set.
s = eval(input('enter the list'))
print(set(s))

# c=set()
# for i in s:
#     c.add(i)
# print(c)

c=[]
for i in s:
    if i not in c:
        c+=[i]
print(set(c))

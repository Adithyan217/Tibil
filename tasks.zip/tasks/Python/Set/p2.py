# Python program to find the union of two sets.
a={1,2,3,4,5}
b={3,4,5,6,7,8,9,0}


# for i in a:
#     b.add(i)
# print(b)


# c=[]
# for i in a:
#         c+=[i]
# for i in b:
#     if i not in c:
#         c+=[i]
# print(set(c))

print(a.union(b))
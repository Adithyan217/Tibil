# Python program to find the difference between two sets.

a={1,2,3,4,5}
b={3,4,5,6,7,8,9,0}

c=set()
for i in a:
    if i not in b:
        c.add(i)
print(c)
# print(a-b)
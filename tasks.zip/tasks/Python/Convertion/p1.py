# Python program to convert a string to a list of characters.
a=input('enter the string : ')


# list=[]
# for i in a:
#     list+=[i]
# print(list)

print([i for i in a])



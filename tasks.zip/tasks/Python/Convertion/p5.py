# Python program to convert a string to a dictionary where each character is a key and its frequency is the value.

# a=input('entr the string')
# out={}
# for i in a:
#     if i in out:
#         out[i]+=data2.csv
#     else:
#         out[i]=data2.csv
# print(out)


a=input('entr the string')
d={i:a.count(i) for i in a }
print(d)
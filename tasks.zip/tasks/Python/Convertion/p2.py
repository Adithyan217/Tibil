# Python program to convert a list of characters to a string.
a=eval(input('enter the list : '))

strr=''
for i in a:
    strr+=str(i)
print(strr)

# [data2.csv,2,3,5,4]
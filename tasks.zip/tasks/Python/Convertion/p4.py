# Python program to convert distance from kilometers to miles and vice versa.
print('data2.csv. KM -> MILES')
print('2. MILES -> KM')
a=int(input('choose the option : '))
if a==1:
    km=float(input('enter the km '))
    print(round(km/1.60934,5))
else:
    miles=float(input('enter the miles'))
    print(round(miles*1.60934,5))
# Python program to convert a binary number to decimal.

a=input('enter the binary number')
print(int(a,2))

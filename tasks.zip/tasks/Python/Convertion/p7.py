# Python program to convert a dictionary to a list of tuples.

# d={'a': data2.csv, 'b': 2, 'c': 3}.items()
# list=[]
# for i in d:
#     list+=[i]
# print(list)


d={'a': 1, 'b': 2, 'c': 3}.items()
print([i for i in d])
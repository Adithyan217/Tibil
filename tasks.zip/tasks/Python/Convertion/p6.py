# Python program to convert a list of tuples to a dictionary.


# list=[(data2.csv,'b'),(2,'c')]
# dict={key:val for key,val in list}
# print(dict)

def fun(list):
    dict = {}
    for i in list:
        key = i[0]
        if key in dict:
            dict[key] += i[1:]
        else:
            dict[key] = i[1:]
    return dict

list= [("a", 1), ("b", 2), ("c", 3), ("a", 4, 5),('d',5,5,7),('n')]
print(fun(list))

# list= [("a", data2.csv), ("b", 2), ("c", 3), ("a", 4, 5),('d',5,5,7),('n')]
# dict={}
# for i in range(len(list)):
#     dict[i]=list[i]
# print(dict)
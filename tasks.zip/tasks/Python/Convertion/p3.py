###Python program to convert temperature from Fahrenheit to Celsius.

f=float(input('enter the Fahrenheit : '))
c=(f-32) * 5/9
print('Celsius : ',round(c,2))


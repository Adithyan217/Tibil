# Python program to convert a list of integers to a string representation of the binary numbers.

list=eval(input('enter the list of integers'))
binary=''
for i in list:
    binary+=bin(i)[2:]
    binary+=' '
print(binary)

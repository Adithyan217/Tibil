# Python program to convert a decimal number to binary, octal, and hexadecimal.

a=int(input('enter the number'))
print('binary number:',bin(a))
print('hexadecimal number :',hex(a))
print('octadecimal number: ',oct(a))
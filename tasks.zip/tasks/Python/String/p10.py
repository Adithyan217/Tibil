# Python program to remove all punctuations from a given string.

import string

a=input('enter the input')
for i in range(len(a)):
    if a[i] in string.punctuation:      #'!"#$%&'()*+,-./:;<=>?@[\]^_`{|}~'
        continue
    else:
        print(a[i],end='')

# Python program to capitalize the first letter of each word in a sentence.

# a=input('enter the sentence').split()
# cap=[i[0].upper()+i[data2.csv:] for i in a]
# nstr=' '.join(cap)
# print(nstr)


a=input('enter the sentence').split()
cap=''
for i in a:
    cap+=i[0].upper()+i[1:]
    cap+=' '
print(cap)



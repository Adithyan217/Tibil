# Python program to check if a given string is a pangram or not.



# a=input('enter the string')
# z='abcdefghijklmnopqrstuvwxyz'
# for i in z:
#     if i.lower() not in a:
#         print('not panagram')
#         break
# else:
#         print('panagram')


def pangram(a):
    z = 'abcdefghijklmnopqrstuvwxyz'
    for i in z:
        if i not in a.lower():
            return False
    return True

if pangram(input('enter the string'))==True:
    print('PANGRAM')
else:
    print('NOT PANGRAM')


# Python program to check if a given string is a palindrome or not (ignoring spaces and case).

a=input('enter the string: ')
b=''
for i in range(len(a)):
    v = a[i].split()
    print(v)
    if 'A' <= a[i] <= 'Z':    #a[i].isupper()
        b += chr(ord(a[i]) + 32) #a[i].lower()
    elif a[i]==' ':
        continue
    else:
        b += a[i]
    # print(b)

if b==b[::-1]:
    print('pali')
else:
    print('not')
print(a.upper())
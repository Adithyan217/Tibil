# Python program to find the longest word in a given string.

a=input(" enter the string ").split()
lw=''
max=0
for i in a:
    if len(i)>max:
        max=len(i)
        lw=i
print(lw)




# print(max(input(" enter the string ").split(),key=len))

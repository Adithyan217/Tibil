# Python program to reverse words in a given string.


a=input('enter the string: ').split()
out=''
for i in range(len(a)):
    out+=a[i][::-1]
    out+=' '
print(out)


# print(list(map(lambda i:i[::-data2.csv],input('enter the string: ').split())))
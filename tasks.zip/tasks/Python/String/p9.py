# Python program to check if a given string is a valid palindrome or not.

# a=input('enter the string')
# for i in a:
#     if a==a[::-data2.csv]:
#         print('palindrome')
#     else:
#         print('not a palindrome')

b=lambda a:'palindrome' if a==a[::-1] else 'not a palindrome'
print(b(input('enter the string')))

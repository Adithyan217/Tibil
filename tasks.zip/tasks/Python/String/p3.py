# Python program to check if two strings are anagrams of each other.
def anagram(a,b):
    print(sorted(a))
    print(sorted(b))
    if sorted(a) == sorted(b):
        print("anagram")
    else:
        print("not anagram")
anagram(input("enter"),input("enter"))

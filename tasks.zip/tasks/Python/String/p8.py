# Python program to find the frequency of each word in a string.

a=input('enter the string').split()
out={}
for i in range(len(a)):
    out[a[i]]=a.count(a[i])
print(out)


# a=input('enter the string').split()
# print({a[i]:a.count(a[i]) for i in range(len(a))})
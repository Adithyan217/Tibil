# Python program to count the number of vowels and consonants in a string.

a=input('enter the string: ')
v=0
c=0
for i in a:
    if i.lower() in 'aeiou':
            # print(i,end=' ')
            v+=1
    elif i.isalpha():
            # print(i,end=' ')
            c+=1


print('Number of vowels =',v)
print('Number of consonants =',c)
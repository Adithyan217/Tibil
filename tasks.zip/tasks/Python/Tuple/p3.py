# Python program to find the index of a given item in a tuple.

tup=eval(input('enter the data'))
val=eval(input('enter the element'))
a=[]
for i in range(len(tup)):
    if val==tup[i]:
        a+=[i]
print("the index is",a)




# def ind(tup,val):
#     a=[]
#     for i in range(len(tup)):
#         if val == tup[i]:
#             a+=[i]
#     return a
#
# print("the index is",ind(eval(input('enter the data')),eval(input('enter the element'))))
# Python program to find the product of elements in a tuple.

# tup=eval(input('enter the tuple'))
# product=data2.csv
# for i in tup:
#     product*=i
# print(product)


def product(tup):
    pro = 1
    for i in tup:
        pro *= i
    return pro
print(product(eval(input('enter the tuple'))))
# Python program to check if two tuples have the same elements.

tup1=eval(input('enter the tuple'))
tup2=eval(input('enter the tuple'))

if set(tup1)==set(tup2):
    print('same same')
else:
    print('different')





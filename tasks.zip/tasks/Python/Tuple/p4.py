# Python program to count the occurrences of a specific element in a tuple.


# tup=eval(input('enter the tuple'))
# elem=eval(input('enter the elem'))
# count=0
# for i in range(len(tup)):
#     if elem == tup[i] :
#         count+=data2.csv
# print("count of element :",count)

def count(tup,elem):
    count = 0
    for i in range(len(tup)):
        if elem == tup[i]:
            count += 1
    return count

print("count of element :",count(eval(input('enter the tuple')), eval(input('enter the elem'))))


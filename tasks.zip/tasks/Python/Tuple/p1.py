# Python program to find the maximum and minimum elements in a tuple.


# tup=eval(input('enter the tuple'))
# max=tup[0]
# min=tup[0]
# for i in tup:
#     if i>max:
#         max=i
# print("maximum element:", max)
#
# for i in tup:
#     if i<min:
#         min=i
# print("minimum element:", min)




def minimum(tup):
    min = tup[0]
    for i in tup:
        if i < min:
            min = i
    return min

def maximum(tup):
    max = tup[0]
    for i in tup:
        if i > max:
            max = i
    return max

tup=eval(input('enter the tuple'))
print("minimum element:", minimum(tup))
print("maximum element:", maximum(tup))

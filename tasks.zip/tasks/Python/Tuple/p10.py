# Python program to find the length of the longest increasing subsequence in a tuple of integers.
a=(15,10,1, 22, 9, 33, 21, 50, 41,111, 60)
b=[]
max=0
for i in range(len(a)):
    if a[i]>max:
        max=a[i]
        b+=[a[i]]
print(tuple(b))
print("length of the longest increasing subsequence :", len(b))

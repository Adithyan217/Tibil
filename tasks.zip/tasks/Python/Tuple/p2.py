# Python program to concatenate two tuples.

# def concate(tup1,tup2):
#     return tup1+tup2
#
# tup=concate(eval(input('enter the tuple: ')),eval(input('enter the tuple: ')))
# print(tup)
#


print(eval(input('enter the tuple: '))+eval(input('enter the tuple: ')))
# (4,3,2,data2.csv) (4,3,2,data2.csv)
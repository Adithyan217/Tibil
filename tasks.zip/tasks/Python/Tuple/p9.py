# # Python program to find the median of elements in a tuple.


def median(tup):
    sorttup = sorted(tup)
    n = len(sorttup)
    if n % 2 == 0:
        mid1 =n // 2
        print(mid1)
        mid2 = (n//2) - 1
        print(mid2)
        median = (sorttup[mid1] + sorttup[mid2]) / 2
    else:
        mid = n // 2
        median = sorttup[mid]
    return median

print(median(eval(input('enter the tuple'))))










# for even it will take index number half and half minus one 
# Python program to find the frequency of each element in a tuple.


# tup=eval(input('enter the tuple'))
# out={}
# for i in tup:
#     if i in out:
#         out[i]+=data2.csv
#     else:
#         out[i]=data2.csv
#
# print(out)

def frequency(tup):
    out={}
    for i in tup:
        if i in out:
            out[i] += 1
        else:
            out[i] = 1
    return out
print(frequency(eval(input('enter the tuple'))))

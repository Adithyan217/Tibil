# Python program to find the index of the first occurrence of a given element in a tuple.

# tup=eval(input('enter the data'))
# val=eval(input('enter the element'))
#
# for i in range(len(tup)):
#     if val==tup[i]:
#         print(tup[i],"is at the index",i)
#         break
# else:
#         print('element not in tuple')
#

def ind(tup, val):
    for i in range(len(tup)):
        if val == tup[i]:
            return i
    else:
        return 'not found so elem not in tuple '

print("the index is",ind(eval(input('enter the data')),eval(input('enter the element'))))
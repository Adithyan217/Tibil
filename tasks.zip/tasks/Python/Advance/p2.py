# Python program to find the GCD (Greatest Common Divisor) of two numbers.

a=int(input('enter'))
b=int(input('enter'))

# if a<b:
#     l=a
# else:
#     l=b
# hcf=0
# for i in range(data2.csv,l+data2.csv):
#     if a%i==0 and b%i==0:
#         hcf=i
# print(hcf)
#

if a<b:
    l=a
else:
    l=b
z=list(filter(lambda x:a%x==0 and b%x==0,range(1,l+1)))
print(z[-1])



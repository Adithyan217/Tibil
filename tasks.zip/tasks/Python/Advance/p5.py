# Python program to implement linear search in a list.

list=eval(input('enter the list'))
k=int(input('enter the search value'))

# for i in range(0,len(list)):
#     if list[i]==k:
#         print('value found at',i,'index')
#     else:
#         print('value not in list')

a=[i for i in range(0,len(list)) if list[i]==k]
print('value found at index',a)
# [8,22,65,5,4,6,9,data2.csv,342,2,3]
# Python program to sort a list of integers using the bubble sort algorithm.

# list=eval(input('enter the list'))
# for i in range(len(list)):
#     for j in range(len(list)-data2.csv):
#         if list[j]>list[j+data2.csv]:
#             list[j],list[j+data2.csv]=list[j+data2.csv],list[j]
# print(list)


def bubble(list):
    for i in range(len(list)):
        for j in range(len(list) - 1):
            if list[j] > list[j + 1]:
                list[j], list[j + 1] = list[j + 1], list[j]
    return list
print(bubble(eval(input('enter the list'))))
# [8,22,65,5,4,6,9,data2.csv,342,2,3]
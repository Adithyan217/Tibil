# Python program to generate Fibonacci series up to n terms.

def fibonacci(n):
    a = 0
    b = 1
    fib = 0
    if n<=0:
        print('wrong input')
    for i in range (1,n+1):
        print(fib,end=' ')
        a=b
        b=fib
        fib = a + b



# fibonacci(int(input('enter the number')))
#
#
# n=int(input('enter the number'))
# num1=0
# num2=data2.csv
# sum=0
# if n < 0:
#     print("Incorrect input")
# for i in range(0,n):
#     print(sum,end=' ')
#     num1=num2
#     num2=sum
#     sum=num1+num2
# # print(sum) #make range to n-data2.csv
#

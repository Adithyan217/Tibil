# Python program to find the LCM (Least Common Multiple) of two numbers.

a=int(input('enter the number: '))
b=int(input('enter the number: '))

# from math import *
# print(lcm(a,b))

#
if a<b:
    h=b
else:
    h=a
z=list(filter(lambda x:x%a==0 and x%b==0,range(h,(a*b)+1)))
print(z[0], 'is the lcm')



# if a<b:
#     h=b
# else:
#     h=a
# for i in range(h,(a*b)+data2.csv):
#     if (i%a==0) and (i%b==0):
#         print(i, ' is the lcm')
#         break

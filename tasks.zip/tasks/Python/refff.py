# a = 66        # initialize the value of a
# b = 8        # initialize the value of b
# print('a&b:', a&b)
# print('a|b:', a|b)
# print('a^b:', a^b)
# print('~a:', ~a)
# print('a<<b:', a<<b)
# print('a>>b:', a>>b)

# a = {"Rose", "Lotus"}
# b = {"Rose", "Lotus"}
# c = a
# d=b
# g=a
# id(c)
# id(a)
# print(a is b)

# a=9.2
# b=a//2
# c=a/2
# print(b)
# print(c)

# a='123'
# print(bool(a))

# a=5
# b=2
# print(bin(a))
# print(bin(b))
# c=a<<b
# print(bin(c))
# print(c)

# a={data2.csv:'aa',2:'bb'}
# print(str(a))

# a="qwrjukii"
# print(a)

# a=3.4
# print(complex(a))


# def add(num1: int, num2: int) -> int:
# 	"""Add two numbers"""
# 	num3 = num1 + num2
#
# 	return num3
#
# # Driver code
# num1, num2 = 5, 15
# ans = add(num1, num2)
# print(f"The addition of {num1} and {num2} results {ans}.")
#

# a="yogi"
# print(bool(a))
#
# a=10
# b=10
# c=2
#
# print(id(a))
# print(id(b))
# print(a is b)

# def tri_recursion(k):
#   if(k > 0):
#     result = k + tri_recursion(k - data2.csv)
#     print(result)
#   else:
#     result = 0
#   return result
#
# print("\n\nRecursion Example Results")
# tri_recursion(6)


# class abc:
#     def __init__(self,name,place):
#         self.name=name
#         self.place=place
#
#     def __disp__(self):
#         print(self.name,self.place)
#
# obj1=abc('adi','chmni')
#
#
# abc.__disp__(obj1)

# a=open('boom','r')
# print(a.read())

# file = open('file.txt','w')
# file.write("Here we write a command")
# file.write("Hello users of JAVA POINT")
# file.close()

# a = open('file2.txt','a')
# # a.write("yogesh poda myre")
# # print(a.read())
# data = 'hello guys \n'
# data2.csv = 'how are you \n'
#
# a.writelines([data,data2.csv])
# a.close()

# a = open('file2.txt', 'r')
# # # n=input('enter the number')
# # l1=a.readline()
# # l2=a.readline()
# # l3=a.readline()
# # # b=open('file.txt','a')
# # # b.write(r)'
# # print(l3)
# for i in a:
#     if i=='guys':
#         print(i,end='')

# a=int(input('enter the number'))
# b=int(input('enter the number'))
# c=int(input('enter the number'))
# d=int(input('enter the number'))
# e=int(input('enter the number'))
#
# if a<b and a<c and a<d and a<e:
#     print(a)
# elif b<c and b<d and b<e:
#     print(b)
# elif c<d and c<e:
#     print(c)
# elif d<e:
#     print(d)
# else:
#     print(e)


# a=int(input('enter the number'))
# b=int(input('enter the number'))
# c=int(input('enter the number'))
# d=int(input('enter the number'))
# e=int(input('enter the number'))
# a=[a,b,c,d,e]
# a.sort()
# # print(a)
# # print(max(a))
# print(min(a))
# # print(a[-data2.csv])
#


# n=int(input('enter'))
# for i in range(2,n):
#     if n%i==0:
#         print('not a prime number')
#         break
# else:
#     print('Prime')





# Python program to
# demonstrate private members

# Creating a Base class

# class Base:
# 	def __init__(self):
# 		self.a = "GeeksforGeeks"
# 		self.__c = "GeeksforGeeks"
#
# # Creating a derived class
# class Derived(Base):
# 	def __init__(self):
#
# 		# Calling constructor of
# 		# Base class
# 		Base.__init__(self)
# 		print("Calling private member of base class: ")
# 		print(self.__c)
#
#
# # Driver code
# obj1 = Base()
# print(obj1.a)
# print(obj1._Base__c)

# Uncommenting print(obj1.c) will
# raise an AttributeError

# Uncommenting obj2 = Derived() will
# also raise an AttributeError as
# private member of base class
# is called inside derived class


# class India():
# 	def capital(self):
# 		print("New Delhi is the capital of India.")
#
# 	def language(self):
# 		print("Hindi is the most widely spoken language of India.")
#
# 	def type(self):
# 		print("India is a developing country.")
#
#
# class USA():
# 	def capital(self):
# 		print("Washington, D.C. is the capital of USA.")
#
# 	def language(self):
# 		print("English is the primary language of USA.")
#
# 	def type(self):
# 		print("USA is a developed country.")
#
#
# obj_ind = India()
# obj_usa = USA()
# for i in (obj_ind, obj_usa):
# 	i.capital()
# 	i.language()
# 	i.type()


# Python program showing
# abstract base class work
# from abc import ABC, abstractmethod


# class Polygon():
#
#     # @abstractmethod
#     # def noofsides(self):
#     #     pass


# class Triangle():
#
#     # overriding abstract method
#     def noofsides(self):
#         print("I have 3 sides")
#
#
# class Pentagon():
#
#     # overriding abstract method
#     def noofsides(self):
#         print("I have 5 sides")
#
#
# class Hexagon():
#
#     # overriding abstract method
#     def noofsides(self):
#         print("I have 6 sides")
#
#
# class Quadrilateral():
#
#     # overriding abstract method
#     def noofsides(self):
#         print("I have 4 sides")
#
#
# # Driver code
# R = Triangle()
# R.noofsides()
#
# K = Quadrilateral()
# K.noofsides()
#
# R = Pentagon()
# R.noofsides()
#
# K = Hexagon()
# K.noofsides()


# class math():
# 	def add(self,a, b):
# 		print(a + b)
#
# 	def add(self,a, b, c):
# 		print(a + b + c)
# cal=math()
# cal.add(2,3,6)

# class boom():
# 	def sub(self,m,n):
# 		print(m-n)
#
# class boombi(boom):
# 	def sub(self,m,n,z):
# 		print(m-n-z)
#
# b=boom()
# c=boombi()
#
# b.sub(data2.csv,2)
# c.sub(2,3,4)

# import json
#
# # JSON string
# employee = '{"id":"09", "name": "Nitin", "department":"Finance"}'
# print("This is JSON", type(employee))
#
# print("\nNow convert from JSON to Python")
#
# # Convert string to Python dict
# employee_dict = json.loads(employee)
# print("Converted to Python", type(employee_dict))
# print(employee_dict)


# Python program to read
# json file


# import json
#
# # Opening JSON file
# f = open('data.json', )
#
# # returns JSON object as
# # a dictionary
# data = json.load(f)
#
# # Iterating through the json
# # list
# for i in data['emp_details']:
#     print(i)
#
# # Closing file
# f.close()

# is_even_list = [lambda i: i * 10 for i in range(data2.csv, 5)]
# for item in is_even_list:
# 	print(item())

# def even():
# 	for i in range (data2.csv,5):
# 		print(i*10)
# even()

# even=lambda i: (for i in range(data2.csv,5):i*10)
# 	print(even())

# x =print([i*10 for i in range(data2.csv,5) ])


# Max = lambda a, b : a if(a > b) else b
# print(Max(data2.csv, 2))

# b=print(list(filter(lambda i:i%2==0,range(data2.csv,10))))

# a=[i*2 for i in range(data2.csv,5)if i%2==0]
# print(a)

# keys = ['a', 'b', 'c', 'd', 'e']
# values = [data2.csv, 2, 3, 4, 5]
#
# # but this line shows dict comprehension here
# myDict = {k: v for (k, v) in zip(keys, values)}
#
# # We can use below too
# # myDict = dict(zip(keys, values))
#
# print(myDict)


# def myFun(*arg):
#     sum=0
#     for i in arg:
#         sum+=i
#     print(sum)
#
#
# myFun(data2.csv,2,3,4,5)

# def boom(**kwargs):
#     for k,v in kwargs.items():
#         print(k,"==",v)
#     print(kwargs)
#
#
# boom(first='hi',nd='helo')
#
# def add(x,y):
#     return x+y
# def mull(x,y):
#     return x*y


# # importing sqrt() and factorial from the
# # module math
# from math import *
#
# # if we simply do "import math", then
# # math.sqrt(16) and math.factorial()
# # are required.
# print(sqrt(16))
# print(factorial(6))
# print(gcd(10,20,30,40))



# a = [data2.csv, 2, 3]
# try:
# 	print ("Second element = ",(a[data2.csv]))
#
# 	print ("Fourth element = %d" %(a[3]))
#
# except:
# 	print ("An error occurred")




















# import copy
# li1 = [data2.csv, 2, [3, 5], 4]
# li2 = copy.copy(li1)
# print("li2 ID: ", id(li2), "Value: ", li2)
# li3 = copy.deepcopy(li1)
# print("li3 ID: ", id(li3), "Value: ", li3)
# print(id(li1))


















#
# a = [data2.csv, 2, 3]
# try:
# 	print("Second element = %d" % (a[data2.csv]))
#
# 	print("Fourth element = %d" % (a[3]))
#
# except:
# 	print("An error occurred")




# import threading


# def print_cube(num):
# 	print("Cube: {}" .format(num * num * num))
#
#
# def print_square(num):
#      print("Square: {}" .format(num * num))
#
#
# print_cube(10)
# print_square(10)
#
# print("Done!")

#
# import threading
# import os
#
#
# def task1():
#     print("Task data2.csv assigned to thread: {}".format(threading.current_thread().name))
#     print("ID of process running task data2.csv: {}".format(os.getpid()))
#
#
# def task2():
#     print("Task 2 assigned to thread: {}".format(threading.current_thread().name))
#     print("ID of process running task 2: {}".format(os.getpid()))
#
#
# if __name__ == "__main__":
#     print("ID of process running main program: {}".format(os.getpid()))
#     print("Main thread name: {}".format(threading.current_thread().name))
#
#     t1 = threading.Thread(target=task1, name='t1')
#     t2 = threading.Thread(target=task2, name='t2')
#
#     t1.start()
#     t2.start()
#
#     t1.join()
#     t2.join()


# from asyncio import *
#
#
# async def fn():
#     print("one")
#     # await sleep(data2.csv)
#     await fn2()
#     print('four')
#     await sleep(data2.csv)
#     print('five')
#     await sleep(data2.csv)
#
#
# async def fn2():
#     await sleep(data2.csv)
#     print("two")
#     await sleep(data2.csv)
#     print("three")
#     await sleep(data2.csv)
#
#
#
# run(fn())


# a=10
# b=10
# print(id(a),id(b))
# print(a)
















######################
##################
#############
############
###############
#######





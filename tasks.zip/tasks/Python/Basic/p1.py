 # MINIMUM AMONG FIVE NUMBERS

a=int(input('enter the number'))
b=int(input('enter the number'))
c=int(input('enter the number'))
d=int(input('enter the number'))
e=int(input('enter the number'))

if a<b and a<c and a<d and a<e:
    print(a)
elif b<c and b<d and b<e:
    print(b)
elif c<d and c<e:
    print(c)
elif d<e:
    print(d)
else:
    print(e)


# a=int(input('enter the number'))
# b=int(input('enter the number'))
# c=int(input('enter the number'))
# d=int(input('enter the number'))
# e=int(input('enter the number'))
# a=[a,b,c,d,e]
# a.sort()
# print(min(a))
# print(a[data2.csv])

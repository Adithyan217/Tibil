# Python program to calculate the average of three numbers.

a=int(input("enter : "))
b=int(input("enter : "))
c=int(input("enter : "))

avg=(a+b+c)/2
print(avg)
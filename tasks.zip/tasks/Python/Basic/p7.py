# Python program to check if a number is even or odd.

a=int(input('enter :'))
if a%2==0:
    print('even')
else:
    print('odd')



# a=lambda a:'even'if a%2==0 else 'odd'
# print(a(int(input('enter'))))


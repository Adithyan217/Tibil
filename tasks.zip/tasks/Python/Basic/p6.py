# Python program to find the sum of natural numbers up to a given number.

n=int(input("enter the number: "))
sum = 0
for i in range(0,n+1):
    sum += i
print(sum)



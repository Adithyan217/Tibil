# Python program to calculate the square root of a number.
import math

a=int(int(input('enter :')))
b=a**(1/2)
# b=math.sqrt(a)
print(b)
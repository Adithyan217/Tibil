# Python program to remove a specific key-value pair from a dictionary.
d = {'a': 5, 'b': 3, 'c': 8, 'd': 1}

# del d[eval(input('enter the key'))]

# d.pop(eval(input('enter the key')))

# print(d)
print(d['a'])
key=eval(input('enter the key'))
a={k:d[k] for k in d if k!=key}
print(a)

# for k in d:
#     print(k)
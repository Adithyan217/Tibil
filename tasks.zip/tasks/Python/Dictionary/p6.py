# Python program to sort a dictionary by its values.

d = {'a': 5, 'b': 3, 'c': 8, 'd': 1}.items()
# a=d.items()
# print(a)
# print(type(a))


###using buble sort
# def sort(d):
#     item = list(d)
#     print(item)
#     for i in range(len(item)):
#         # print(item[i])
#         for j in range(len(item)- data2.csv):
#             # print(item[j][data2.csv])
#             if item[j][data2.csv] > item[j + data2.csv][data2.csv]:
#                 item[j], item[j + data2.csv] = item[j + data2.csv], item[j]
#     print(item)
#     sd = dict(item)
#     return sd
#
# print(sort(d))



sortd=dict(sorted(d,key=lambda i:i[1]))
print(sortd)
#




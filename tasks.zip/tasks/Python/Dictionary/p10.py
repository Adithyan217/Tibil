# Python program to check if two dictionaries have the same keys.
d1 = {'a': 5, 'b': 3, 'c': 8, 'd': 1}
d2 = {'o': 5, 'b': 3, 'f': 8, 'g': 1}

k1=list(d1.keys())
k2=list(d2.keys())

for i in k2:
    if i in k1:
        print('two dictionaries have same keys ')
        break
else:
        print('no same keys')




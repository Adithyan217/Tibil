# Python program to find the keys corresponding to the maximum and minimum values in a dictionary.

d = {'a': 5, 'b': 3, 'c': 8, 'd': 1}.items()

sortd=dict(sorted(d,key=lambda i:i[1]))
print(sortd)

list=[]
for i in sortd:
    list+=[i]
print('minimum values key' ,list[0])
print('maximum values key' ,list[-1])
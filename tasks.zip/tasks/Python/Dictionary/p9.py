# Python program to find the sum of all values in a dictionary.

d = {'a': 5, 'b': 3, 'c': 8, 'd': 1}
v=list(d.values())
sum=0
for i in v:
    sum+=i
print(sum)

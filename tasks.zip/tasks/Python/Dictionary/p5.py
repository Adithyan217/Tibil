# Python program to multiply all values in a dictionary by a certain number.
d={1:22,2:'a',3:32,4:12}.items()

# md={}
# mul=int(input('enter the number'))
# for k,v in d:
#     md[k]=v*mul
# print(md)


mul=int(input('enter the number'))
print({k:v*mul for k,v in d})
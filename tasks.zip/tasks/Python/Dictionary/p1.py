# Python program to find the length of a dictionary.
d={1:'a',2:'b',3:'c',4:'d'}
print(len(d))
# print(len(d.items()))
# print(len(d.keys()))
# print(len(d.values()))
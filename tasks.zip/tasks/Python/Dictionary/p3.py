# Python program to count the occurrences of each word in a string and store them in a dictionary.


a=input('enter the string').split()


# out={}
# for i in range(len(a)):
#     out[a[i]]=a.count(a[i])
# print(out)


print({a[i]:a.count(a[i]) for i in range(len(a))})
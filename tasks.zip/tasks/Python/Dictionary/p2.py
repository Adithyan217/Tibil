# Python program to check if a given key exists in a dictionary.

d={1:'a',2:'b',3:'c',4:'d'}


# key=eval(input('enter the key'))
# c=d.keys()
# if key in c:
#     print('key exists')
# else:
#     print(('key not found'))

a=lambda key:print('key exists') if key in d.keys() else print(('key not found'))
a(eval(input('enter the key')))
# Python program to find the intersection of two lists.

# list=eval(input('enter the list'))
# list2=eval(input('enter the list'))
# out=[]
# for i in list:
#     if i in list2:
#         out+=[i]
# print(out)




list=eval(input('enter the list'))
list2=eval(input('enter the list'))
print([i for i in list if i in list2])
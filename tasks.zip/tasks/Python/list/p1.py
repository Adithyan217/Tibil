# Python program to find the second largest number in a list.
list=eval(input('enter the list'))


sort=sorted(list)
print(sort[-2])

# for i in range(len(list)):
#     for j in range(len(list)-data2.csv):
#         if list[j]>list[j+data2.csv]:
#             list[j],list[j + data2.csv]=list[j+data2.csv],list[j]
# print(list[-2])


# [8,22,65,5,4,6,9,data2.csv,342,2,3]
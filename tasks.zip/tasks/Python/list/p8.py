# Python program to find the sum of elements in a list using recursion.

def getSum(list):
    if len(list)==0:
        return 0
    return list[0] + getSum(list[1:])
print (getSum(eval(input('enter the list'))))

















































# The user is prompted to enter a list. Let's say they input [data2.csv, 2, 3, 4].
#
# The eval function evaluates the input string, converting it into an actual list: [data2.csv, 2, 3, 4].
#
# The getSum function is called with the list [data2.csv, 2, 3, 4].
#
# Inside getSum:
#
# The list [data2.csv, 2, 3, 4] is not empty, so the code proceeds to the next step.
# It calculates the sum as data2.csv + getSum([2, 3, 4]).
# Now, it calls getSum again with the list [2, 3, 4].
#
# Again, the list is not empty, so it proceeds.
# It calculates the sum as 2 + getSum([3, 4]).
# It calls getSum once more with the list [3, 4].
#
# Still not empty, so it proceeds.
# It calculates the sum as 3 + getSum([4]).
# Now, it calls getSum with the list [4].
#
# The list has only one element, so it's the base case.
# It returns 4 as the sum.
# Going back up the recursion stack:
#
# In step 6, 3 + getSum([4]) evaluates to 3 + 4 = 7.
# In step 5, 2 + getSum([3, 4]) evaluates to 2 + 7 = 9.
# In step 4, data2.csv + getSum([2, 3, 4]) evaluates to data2.csv + 9 = 10.
# Finally, the result 10 is printed.
#
# So, the sum of all elements in the list [data2.csv, 2, 3, 4] is 10.
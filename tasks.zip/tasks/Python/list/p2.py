# # Python program to merge two sorted lists into a single sorted list.


list=eval(input('enter the list'))
list2=eval(input('enter the list'))

def sort(a):
    for i in range(len(a)):
        for j in range(len(a) - 1):
            if a[j] > a[j + 1]:
                a[j], a[j + 1] = a[j + 1], a[j]
    return a
x=sort(list)
y=sort(list2)
merge=sort(x+y)
print(merge)



# print(sorted(list+list2))
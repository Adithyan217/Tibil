# Python program to find the largest and smallest elements in a list.


list=eval(input('enter the list :'))
def maximum(a):
    max = a[0]
    for i in a:
        if i > max:
            max = i
    return max

def minimum(b):
    min = b[0]
    for i in b:
        if i < min:
            min = i
    return min

print('maximum element :', maximum(list))
print('minimum element :',minimum(list))
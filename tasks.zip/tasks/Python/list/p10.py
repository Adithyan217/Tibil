def reverse(list, size):
    out = []
    for i in range(0, len(list),size):
        sublist = list[i:i+size] ### slicing is done from i to i+size ex=0-3
        out+=sublist[::-1]  ## reversing the obtained subsets
    return out

list = eval(input('enter the list'))
size = int(input('enter the size'))
rev_list = reverse(list,size)
print("OG List:", list)
print("Rev List per size ", size, ":", rev_list)

# [data2.csv, 2, 3, 4, 5, 6, 7, 8, 9]
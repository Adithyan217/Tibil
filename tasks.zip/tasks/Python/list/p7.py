# Python program to remove the nth index element from a list.
list=eval(input('enter the list:'))
index=int(input('enter the index'))
out=[]
for i in range(len(list)):
    if i!=index:
        out+=[list[i]]
print(out)

    # [0,data2.csv,2,3,4,5,6,7,8,9,10]

# z=[i for i in range(len(list)) if i != index]
# print(z)
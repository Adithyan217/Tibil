# Python program to find the frequency of elements in a list.
def frequency(list):
    fre = {}
    for i in list:
        if i in fre:
            fre[i] += 1
        else:
            fre[i] = 1
    return fre

print(frequency(eval(input('enter the list'))))
# Python program to check if a list is sorted in ascending order.
# a=eval(input('enter the list'))
#
# for i in a:
#     if a[0]<a[-data2.csv]:
#         print('ascending')
#         break
# else:
#     print('descending')


z=lambda a:'ascending' if a[0]<a[-1] else 'descending'
print(z(eval(input('enter the list'))))
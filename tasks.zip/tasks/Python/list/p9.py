# Python program to sort a list of strings based on the length of each string.

def sort(list):
    for i in range(len(list)):
        for j in range(0, len(list)-1):
            if len(list[j]) > len(list[j+1]):
                list[j], list[j+1] = list[j+1], list[j]
    return list

print(sort(eval(input('enter the list'))))
        # ['boom','12345678901234567890987654321','12345678909876541sdfghjk654321321','fghjk']
import pandas as pd
import random
from datetime import *
from faker import *

fake = Faker()
row_num=2000000
target_size_mb = 50


def random_date(start,end):
    return start+timedelta(days=random.randint(0,int((end-start).days)))


project_ids = list(range(200, 200 + row_num))
project_names=[fake.company() for _ in range(row_num)]
customer_ids=list(range(1000, 1000 + row_num))
start_dates=[random_date(datetime(2020,1,1),datetime(2024,6,1)) for _ in range(row_num)]
end_dates=[start_date+timedelta(days=random.randint(60,2365)) for start_date in start_dates]
project_managers= [fake.name() for _ in range(row_num)]
project_descriptions= [fake.sentence(nb_words=4) for _ in range(row_num)]
project_statuses= [random.choice(['On Hold', 'In Progress', 'Completed', 'Planned']) for _ in range(row_num)]
project_budgets=[random.randint(100000,1000000) for _ in range(row_num)]
actual_cost=[cost+random.randint(-100000,100000) for cost in project_budgets]
project_category=['BU'+str(random.randint(1,50)) for _ in range(row_num)]
project_locations=[random.choice(['Kerala','Karnataka','Tamil Nadu',''])]
data={
    'project_id':project_ids,
    'project_name':project_names,
    'customer_id':customer_ids,
    'start_date':[date.strftime('%d-%m-%Y') for date in start_dates],
    'end_date':[date.strftime('%d-%m-%Y') for date in end_dates],
    'project_manager':project_managers,
    'project_description':project_descriptions,
    'project_status':project_statuses,
    'project_budget':project_budgets,
    'actual_cost':actual_cost,
    'project_category':project_category,
    'project_location':'India'
}

df=pd.DataFrame(data)
# csv_file=df.to_csv('dummydata.csv',index=False)
# print(df)
#
# # Calculate the approximate memory usage
# print(df.memory_usage(deep=True).sum())
#
# # Save DataFrame to CSV to check the file size
# csv_file = df.to_csv('dummydata.csv', index=False)
#
# import os
# print(os.path.getsize('dummydata.csv') / (1024 * 1024), "MB")

while True:
    new_data = generate_data(row_num)
    df = pd.concat([df, new_data], ignore_index=True)
    # Save DataFrame to CSV to check the file size
    df.to_csv('dummydata.csv', index=False)
    size_mb = os.path.getsize('dummydata.csv') / (1024 * 1024)
    print(f'Current file size: {size_mb:.2f} MB')
    if size_mb >= target_size_mb:
        break

print("Reached target file size.")
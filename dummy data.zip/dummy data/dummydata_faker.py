from faker import Faker
import pandas as pd
import random

# Initialize Faker and random seed for reproducibility
fake = Faker()
random.seed(0)

# Number of rows of dummy data to generate
num_rows = 100

# Generate unique project_ids and customer_ids
project_ids = list(range(1, num_rows + 1))
customer_ids = random.sample(range(1000, 10000), num_rows)  # Generate unique customer IDs

# Generate random data for other columns
project_names = [fake.company() for _ in range(num_rows)]
start_dates = [fake.date_between(start_date='-1y', end_date='today').strftime('%Y-%m-%d') for _ in range(num_rows)]
end_dates = [fake.date_between(start_date='today', end_date='+1y').strftime('%Y-%m-%d') for _ in range(num_rows)]
project_managers = [fake.name() for _ in range(num_rows)]
project_descriptions = [fake.text(max_nb_chars=200) for _ in range(num_rows)]
project_statuses = [fake.random_element(elements=('Active', 'Inactive', 'Completed')) for _ in range(num_rows)]
project_budgets = [round(random.uniform(1000, 1000000), 2) for _ in range(num_rows)]
actual_costs = [round(random.uniform(500, 800000), 2) for _ in range(num_rows)]
project_categories = [fake.random_element(elements=('IT', 'Finance', 'Marketing')) for _ in range(num_rows)]
project_locations = [fake.city() for _ in range(num_rows)]

# Create DataFrame using pandas
df = pd.DataFrame({
    'project_id': project_ids,
    'project_name': project_names,
    'customer_id': customer_ids,
    'start_date': start_dates,
    'end_date': end_dates,
    'project_manager': project_managers,
    'project_description': project_descriptions,
    'project_status': project_statuses,
    'project_budget': project_budgets,
    'actual_cost': actual_costs,
    'project_category': project_categories,
    'project_location': project_locations
})

# Display the first few rows of the generated DataFrame
# print(df.head())
print(df.to_string())


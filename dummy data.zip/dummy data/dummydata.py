import pandas as pd
import numpy as np
import random
import string


def generate_dummy_data(num_rows):
    # Generate unique project_id and customer_id
    project_ids = range(1, num_rows + 1)
    customer_ids = random.sample(range(1000, 1000000), num_rows)

    # Generate random data for other columns
    project_names = ['Project ' + ''.join(random.choices(string.ascii_uppercase + string.digits, k=5)) for _ in
                     range(num_rows)]
    start_dates = pd.date_range(start='2020-01-01', end='2023-12-31', periods=num_rows).strftime('%Y-%m-%d')
    end_dates = pd.date_range(start='2023-01-01', end='2026-12-31', periods=num_rows).strftime('%Y-%m-%d')
    project_managers = random.choices(['Lavanya KR', 'Krishna raj', 'Vinod kannan'], k=num_rows)
    project_descriptions = ['Lorem ipsum dolor sit amet, consectetur adipiscing elit.' for _ in range(num_rows)]
    project_statuses = random.choices(['Active', 'Inactive', 'Completed',','], k=num_rows)
    project_budgets = np.random.uniform(1000, 1000000, num_rows).round(2)
    actual_costs = np.random.uniform(500, 800000, num_rows).round(2)
    project_categories = random.choices(['IT', 'Finance',',', 'Marketing'], k=num_rows)
    project_locations = random.choices(['Bangalore', ',','Chennai','Hyderabad','Kolkata','Delhi', 'Mumbai', 'Pune'], k=num_rows)

    # Create DataFrame
    df = pd.DataFrame({
        'project_id': project_ids,
        'project_name': project_names,
        'customer_id': customer_ids,
        'start_date': start_dates,
        'end_date': end_dates,
        'project_manager': project_managers,
        'project_description': project_descriptions,
        'project_status': project_statuses,
        'project_budget': project_budgets,
        'actual_cost': actual_costs,
        'project_category': project_categories,
        'project_location': project_locations
    })

    return df

num_rows = 316100  # Adjust based on your estimation of row size and target file size
df = generate_dummy_data(num_rows)

df.to_csv('dummy_project_data.csv', index=False)


import pandas as pd

# Load the generated dummy data into a DataFrame (replace 'dummy_project_data.csv' with your file path if applicable)
df = pd.read_csv('dummy_project_data.csv')

# # 1.Check if project_id and customer_id columns have only unique values
# if df['project_id'].nunique() == df.shape[0] and df['customer_id'].nunique() == df.shape[0]:
#     print("All values in project_id and customer_id columns are unique.")
# else:
#     print("Duplicate values found in project_id or customer_id columns.")

# # 2.Replace ',' with '_' in all columns
# df = df.replace(',', '-', regex=True)

# # 3.Convert start_date and end_date columns to 'DD-MM-YYYY' format
# df['start_date'] = pd.to_datetime(df['start_date']).dt.strftime('%d-%m-%Y')
# df['end_date'] = pd.to_datetime(df['end_date']).dt.strftime('%d-%m-%Y')

# # 4.Remove rows with any null values
# df.replace(',', pd.NA,inplace=True)
# df.dropna(inplace=True)

# # 5.Manually provide valid project_manager names
# valid_managers = ['Lavanya KR', 'Krishna raj', 'Rahul Gupta', 'Priya Patel']
#
# # 6.Filter for only Indian locations
# indian_locations = ['Mumbai', 'Bangalore', 'Chennai', 'Kolkata']
#
# # Filter DataFrame to include only valid project managers and Indian locations
# df = df[df['project_manager'].isin(valid_managers) & df['project_location'].isin(indian_locations)]

# # Display the first few rows of the processed DataFrame
# print(df.head())

# Save the processed DataFrame to a new CSV file
df.to_csv('processed_project_data.csv', index=False)

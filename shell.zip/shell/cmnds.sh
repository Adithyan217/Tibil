echo "listing the files"
ls
echo " "
echo "curent working directory"
pwd
echo " "
echo "username"
whoami

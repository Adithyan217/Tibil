#!/bin/bash
# Script to add two numbers

echo "Enter first number:"
read num1

echo "Enter second number:"
read num2

sum=$((num1 + num2))

echo "sum is $sum"

echo "hey guyys"
ls
pwd
touch filesample
cat add.sh
echo "hello rahid"

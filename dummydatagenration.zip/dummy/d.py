import pandas as pd
import random
from datetime import datetime, timedelta
from faker import Faker
import os


fake = Faker()
rows =30                               # 404424
file_size=50

pro_desc=['Development of Software','Website Development,Deployement','Marketing Campaign','Data analysis,project analuysisi','Construction project','Hospitality services']
pro_manager=['Anuroop','Girish','Aditya Murali','Avishek','Rajashekar','Manmeet','LavanyaKR','Krishna Raj','Anup','Himalay','Disha']

def random_date(start, end):
    return start + timedelta(days=random.randint(0, int((end - start).days)))

def dummyd_data(row_num):
    project_ids = list(range(200, 200 + row_num))
    project_names = [fake.company() for _ in range(row_num)]
    customer_ids = list(range(1000, 1000 + row_num))
    start_dates = [random_date(datetime(2020, 1, 1), datetime(2024, 6, 1)) for _ in range(row_num)]
    end_dates = [start_date + timedelta(days=random.randint(60, 2365)) for start_date in start_dates]
    project_managers = [fake.name() for _ in range(row_num)]
    # project_managers = [random.choice(pro_manager) for _ in range(row_num)]
    project_descriptions = [fake.sentence(nb_words=4) for _ in range(row_num)]
    # project_descriptions = [random.choice(pro_desc) for _ in range(row_num)]
    project_statuses = [random.choice(['On Hold', 'In Progress', 'Completed', 'Planned']) for _ in range(row_num)]
    project_budgets = [random.randint(100000, 1000000) for _ in range(row_num)]
    actual_cost = [cost + random.randint(-100000, 100000) for cost in project_budgets]
    project_category = ['BU' + str(random.randint(1, 50)) for _ in range(row_num)]
    project_locations = [random.choice(['Kerala', 'Karnataka', 'Tamil Nadu', '']) for _ in range(row_num)]
    data = {
        'project_id': project_ids,
        'project_name': project_names,
        'customer_id': customer_ids,
        'start_date':start_dates,
        'end_date': end_dates,
        'project_manager': project_managers,
        'project_description': project_descriptions,
        'project_status': project_statuses,
        'project_budget': project_budgets,
        'actual_cost': actual_cost,
        'project_category': project_category,
        'project_location': project_locations
    }
    return pd.DataFrame(data)


sample_data=dummyd_data(rows)
sample_data.to_csv('dummydata.csv', index=False)

start_size=os.path.getsize('dummydata.csv') / (1024 * 1024)
print('sample file size:',start_size)

rows_needed=int((file_size/start_size)*rows)
print("number rows needed for the file size: ", rows_needed)
dummydata=dummyd_data(rows_needed)
dummydata.to_csv('dummydata.csv', index=False)
print("csv file created")


from flask import Flask,request,jsonify
from flask_sqlalchemy import SQLAlchemy



app=Flask(__name__)

app.config['SQLALCHEMY_DATABASE_URI']='postgresql://postgres:root@localhost/api_flask'

db=SQLAlchemy(app)

class Table(db.Model):
    __tablename__='table1'
    col1=db.Column(db.Integer,primary_key=True)
    col2=db.Column(db.String(30),nullable=False)
    col3=db.Column(db.Boolean,nullable=False)

with app.app_context():
    db.create_all()

@app.route('/table1')
def get_tab():
    tab=Table.query.all()
    tab_list=[
        {
            'col1':tab.col1,'col2':tab.col2,'col3':tab.col3
        }
    ]
    return jsonify(tab_list)
if __name__ == '__main__':
    app.run(debug=True)
from flask import *
app=Flask(__name__)
@app.route('/img')
def image():
    image=r'D:\adi\DCIM\Camera\IMG_20210728_180300.jpg'
    return send_file(image, mimetype='image/png')  # for gif - mimetype=gif,vid - mimetype=video/mp4

@app.route('/vid')
def video():
    video=r"C:\Users\shnno\Videos\Captures\vid1.mp4"
    return send_file(video, mimetype='video/mp4')

if __name__ == '__main__':
    app.run(debug=True)
from flask import *
from flask_sqlalchemy import *

app = Flask(__name__)

# Database configuration
app.config['SQLALCHEMY_DATABASE_URI'] = 'postgresql://postgres:root@localhost/api_flask'
##username:password@localhost/database

db = SQLAlchemy(app)


# Define the Book model
class Error(db.Model):
    __tablename__ = 'errors'  ## if the table already exist mention the table name with the structure
    id = db.Column(db.Integer, primary_key=True)
    d_data = db.Column(db.String(80), nullable=False)


with app.app_context():  ## if the table is not created use this to create the table
    db.create_all()

@app.get('/data')
def get_id():
    datas = Error.query.all()
    data_list = [
        {'User id': data.id, 'Data': data.d_data, } for data in datas
    ]
    return jsonify({'Data': data_list})


@app.get('/data/<int:id_s>')
def get_specific_data(id_s):
    try:
        dat = Error.query.get(id_s)
        return jsonify({'id': dat.id, 'Data': dat.d_data})
    except Exception:
        return "ERROR - please mention a valid id "



@app.post('/data')
def create_log():
    try:
        req = request.get_json()
        new_id = Error(id=req["User id"], d_data=req['Data'])
        db.session.add(new_id)
        db.session.commit()
        return jsonify({'message': 'id created'})
    except Exception:
        return "please use proper names for the key"


if __name__ == '__main__':
    app.run(debug=True, port=7777)




























from flask import Flask, request, Response

app = Flask(__name__)

# Set your bearer token
BEARER_TOKEN = 'bearer'

# Function to check bearer token
def check_token(token):
    return token == BEARER_TOKEN

# Function to send a 401 response to the client
def authenticate():
    return Response(
        'Could not verify your access level for that URL.\n'
        'You have to login with proper credentials', 401,
        {'WWW-Authenticate': 'Bearer'})

# Decorator function to check authentication
def requires_auth(f):
    def decorated(*args, **kwargs):
        auth = request.headers.get('Authorization')
        if not auth or not auth.startswith('Bearer ') or not check_token(auth.split(' ')[1]):
            return authenticate()
        return f(*args, **kwargs)
    return decorated

@app.route('/bearer')
@requires_auth
def helloworld():
    return 'Hello, world!!!'

if __name__ == '__main__':
    app.run(debug=True,port=6666)

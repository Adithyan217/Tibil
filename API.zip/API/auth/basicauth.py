from flask import Flask, request, Response

app = Flask(__name__)

# Set your username and password
USERNAME = 'user'
PASSWORD = '1234'

# Function to check username and password
def check_auth(username, password):
    return username == USERNAME and password == PASSWORD

# Function to send a 401 response to the client
def authenticate():
    return Response(
        'Could not verify your access level for that URL.\n'
        'You have to login with proper credentials', 401,
        {'WWW-Authenticate': 'Basic realm="Login Required"'})

# Decorator function to check authentication
def requires_auth(f):
    def decorated(*args, **kwargs):
        auth = request.authorization
        if not auth or not check_auth(auth.username, auth.password):
            return authenticate()
        return f(*args, **kwargs)
    return decorated

@app.route('/')
@requires_auth
def helloworld():
    return 'Hello, world!!!'

if __name__ == '__main__':
    app.run(debug=True,port=7777)




































































# from flask import Flask, request, Response
# from functools import wraps

# app = Flask(__name__)

# # Define your username and password
# USERNAME = 'user'
# PASSWORD = '1234'

# def check_auth(username, password):
#     """Check if a username/password combination is valid."""
#     return username == USERNAME and password == PASSWORD

# def authenticate():
#     """Sends a 401 response that enables basic auth."""
#     return Response(
#         'Could not verify your access level for that URL.\n'
#         'You have to login with proper credentials', 401,
#         {'WWW-Authenticate': 'Basic realm="Login Required"'})

# def requires_auth(f):
#     """Decorator to prompt for basic auth credentials."""
#     @wraps(f)
#     def decorated(*args, **kwargs):
#         auth = request.authorization
#         if not auth or not check_auth(auth.username, auth.password):
#             return authenticate()
#         return f(*args, **kwargs)
#     return decorated

# @app.route('/')
# @requires_auth
# def helloworld():
#     return 'Hello, world!!!'

# if __name__ == '__main__':
#     app.run(debug=True)
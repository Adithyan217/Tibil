from flask import *
from flask_sqlalchemy import *

app = Flask(__name__)

# Database configuration
app.config['SQLALCHEMY_DATABASE_URI'] = 'postgresql://postgres:root@localhost/api_flask'
                                                    ##username:password@localhost/database

db = SQLAlchemy(app)


# Define the Book model
class Task(db.Model):
    __tablename__ = 'task'                              ## if the table already exist mention the table name with the structure
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(80), nullable=False)
    author = db.Column(db.String(80), nullable=False)

with app.app_context():      ## if the table is not created use this to create the table
    db.create_all()


@app.route('/tasks')
def get_tasks():
    tasks=Task.query.all()
    task_list=[
        {'id':task.id,'title':task.title,'author':task.author} for task in tasks
    ]
    return jsonify({'tasks':task_list})

## get specific data
@app.get('/tasks/<int:id_s>')
def get_specific_tasks(id_s):
    taks=Task.query.get(id_s)
    if taks is None:
        return jsonify({'error': 'Task not found'}), 404
    return jsonify({'id': taks.id, 'title': taks.title, 'author': taks.author})

## create a new row
@app.post('/tasks')
def create_task():
    req=request.get_json()
    new_task= Task(id=req['id'],title=req['title'],author=req['author'])
    db.session.add(new_task)
    db.session.commit()
    return jsonify({'message':'task created'}),201

# #PUT update an existing task by ID

@app.route('/tasks/<int:id_s>', methods=['PUT'])
def update_task(id_s):
    task = Task.query.get(id_s)
    req = request.get_json()
    if task is None:
        new_task = Task(id=id_s, title=req['title'], author=req['author'])
        db.session.add(new_task)
        db.session.commit()
        return jsonify({'message': 'task created'}), 201
    if 'title' in req:
        task.title = req['title']
    if 'author' in req:
        task.author = req['author']
    db.session.commit()
    return jsonify({'message': 'Task updated'}), 200


##PATCH METHOD

@app.route('/tasks/<int:id_s>', methods=['PATCH'])
def patch_task(id_s):
    task = Task.query.get(id_s)
    if task is None:
        return jsonify({'error': 'Task not found'}), 404
    req = request.get_json()
    if 'title' in req:
        task.title = req['title']
    if 'author' in req:
        task.author = req['author']
    db.session.commit()
    return jsonify({'message': 'Task partially updated'}), 200


## DELETE a task by ID

@app.route('/tasks/<int:id_s>', methods=['DELETE'])
def delete_task(id_s):
    task = Task.query.get(id_s)
    if task is None:
        return jsonify({'error': 'Task not found'}), 404
    db.session.delete(task)
    db.session.commit()
    return jsonify({'message': 'Task deleted'}), 200


if __name__ == '__main__':
    app.run(debug=True)
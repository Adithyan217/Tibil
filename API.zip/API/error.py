from flask import Flask, jsonify

app = Flask(__name__)

@app.route('/<int:user_id>', methods=['GET'])
def get_user(user_id):
    try:
        if user_id == 1:
            return jsonify({'id': 1, 'name': 'John Doe'})
        else:
            raise Exception({'message': f'User {user_id} not found'})
    except Exception as e:
        return " 404 Error Please check the user id"

if __name__ == '__main__':
    app.run(debug=True,port=6000)
































# from flask import Flask
# from flask_restful import Api, Resource, abort

# app = Flask(__name__)
# api = Api(app)

# # Example resource for handling users
# class UserResource(Resource):
#     def get(self, user_id):
#         if user_id == 1:
#             return {'id': 1, 'name': 'John Doe'}
#         else:
#             # Use abort to raise HTTP errors with custom messages
#             abort(404, message=f"User {user_id} not found")

# # Add resource to the API
# api.add_resource(UserResource, '/user/<int:user_id>')

# @app.errorhandler(404)
# def handle_not_found_error(error):
#     return {'message': 'Resource not found', 'status': 404}, 404

# @app.errorhandler(500)
# def handle_internal_server_error(error):
#     return {'message': 'Internal Server Error', 'status': 500}, 500

# if __name__ == '__main__':
#     app.run(debug=True)

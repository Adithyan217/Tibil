## taking a existing table and performing the operations


from flask import Flask, jsonify, request
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)

# Database configuration
app.config['SQLALCHEMY_DATABASE_URI'] = 'postgresql://postgres:root@localhost/api_flask'
                                                    ##username:password@localhost/database

db = SQLAlchemy(app)


# Define the Book model
class Task(db.Model):
    __tablename__ = 'booms'                              ## if the table already exist mention the table name with the structure
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(30), nullable=False)
    age = db.Column(db.Integer, nullable=False)

@app.route('/tasks')
def get_tasks():
    tasks=Task.query.all()
    task_list=[
        {'id':task.id,'name':task.name,'age':task.age} for task in tasks
    ]
    return jsonify({'tasks':task_list})

@app.post('/tasks')
def create_task():
    req=request.get_json()
    new_task= Task(id=req['id'],name=req['name'],age=req['age'])
    db.session.add(new_task)
    db.session.commit()
    return jsonify({'message':'task created'}),201


if __name__ == '__main__':
    app.run(debug=True)